// Воронин Глеб
// Домашнее задание номер 4

class Book {
    #title;
    #author;
    #year;
    #isIssued;

    constructor(title, author, year) {
        this.#title = title;
        this.#author = author;
        this.#year = year;
        this.#isIssued = false; // Делаем что по умолчанию не выдана
        
        // Защищаем поле #isIssued от изменения напрямую
        Object.defineProperty(this, '#isIssued', {
            writable: false,
            configurable: false
        });
    }

    // Геттеры просто чтоб считать
    get title() {
        return this.#title;
    }

    get author() {
        return this.#author;
    }

    get year() {
        return this.#year;
    }

    get isIssued() {
        return this.#isIssued;
    }
    // Сеттер для #isIssued с обработкой ошибок
    set isIssued(value) {
        if (typeof value === 'boolean') {
            this.#isIssued = value;
        } else {
            throw new Error("Значение isIssued должно быть булевым");
        }
    }

    // Изменяем статус выдачи книги
    toggleIssue() {
        this.#isIssued = !this.#isIssued;
    }
    // Вывод инфы про книгу
    toString() {
        return `${this.title} (${this.year}) - ${this.author} | Выдана: ${this.isIssued}`;
    }
}

class EBook extends Book { // наследуем
    #fileSize;
    #format;

    constructor(title, author, year, fileSize, format) {
        super(title, author, year); // вызов конструктора базового класса
        this.#fileSize = fileSize;
        this.#format = format;
    }
    // Просто геттеры для считки
    get fileSize() {
        return this.#fileSize;
    }

    get format() {
        return this.#format;
    }

    // Переопределяем метод toggleIssue
    toggleIssue() {
        console.log("Эл книги всегда доступны");
    }
    // переопределяем вывод для эл книг
    toString() {
        return `${super.toString()} | ${this.#fileSize}MB (${this.#format})`;
    }
}

class Library {
    #books; // тут храним книги

    constructor() {
        this.#books = [];
    }
    // Метод добавления книги в библеотеку
    addBook(book) {
        if (book instanceof Book) {
            this.#books.push(book);
        } else {
            throw new Error("Добавляемый объект должен быть экземпляром Book или его наследника");
        }
    }

    // Перегруженный метод поиска книги
    findBook(arg1, arg2) {
        try {
            if (arg2 === undefined) {
                // Поиск по названию
                let book = this.#books.find(b => b.title === arg1);
                if (!book) throw new Error("Книга не найдена.");
                return book;
            } else {
                // Поиск по автору и году
                let book = this.#books.find(b => b.author === arg1 && b.year === arg2);
                if (!book) throw new Error("Книга не найдена.");
                return book;
            }
        } catch (error) {
            console.error(error.message);
        }
    }

    // Выводим все книги из библы
    listAllBooks() {
        this.#books.forEach(book => console.log(book.toString()));
    }
}

const library = new Library();

const book1 = new Book("wegweag", 'wegwea', 4324);
const book2 = new Book("esgdwgg", 'bsdfb', 324);
const book3 = new EBook("sdfbmnrt", 'wegwea', 324, 8, "qwef");

library.addBook(book1);
library.addBook(book2);
library.addBook(book3);

library.listAllBooks();
console.log(library.findBook('324'));
console.log(library.findBook('wegwea', '324'))
book1.toggleIssue();
console.log(book1.toString());
book1.toggleIssue();

